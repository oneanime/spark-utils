create
    definer = root@`%` procedure SP_BILL_APPLY_GRADE_STD(IN APPLYID varchar(100), IN IDCARD varchar(20),
                                                         IN PTYPE varchar(10), IN AREACODE varchar(30))
BEGIN
  DECLARE VV_TASK  VARCHAR(50) ;
	
	
set VV_TASK='删除 标准化流水数据';
delete from data_transaction_detail_std where APPLY_ID=APPLYID  AND AREA_CODE =AREACODE;
commit;	
set VV_TASK='删除临时表数据';
delete from data_bill_apply_grade_std_temp where APPLY_ID=APPLYID AND ID_CARD=IDCARD AND TYPE=PTYPE AND AREA_CODE =AREACODE;
commit;

set VV_TASK='删除正式表数据';
delete from data_bill_apply_grade_std where APPLY_ID=APPLYID AND ID_CARD=IDCARD AND TYPE=PTYPE AND AREA_CODE =AREACODE;
commit;
 

set VV_TASK='将 标准化流水 插入中间表中';

insert into  data_transaction_detail_std
select t1.* from data_transaction_detail t1 ,
(select  t.ORG_CODE,t.ACCOUNT,
case when day(START_DATE)>20 then  DATE_SUB(concat(year(START_DATE),substr(START_DATE,6,2),'01'),INTERVAL -1 month) else START_DATE end  START_DATE,
case when day(END_DATE)  <10 then  DATE_SUB(END_DATE,  INTERVAL day(END_DATE) day) else END_DATE   end  END_DATE
from (
select 
ORG_CODE,ACCOUNT,min(TRADE_DATE) START_DATE ,max(TRADE_DATE) END_DATE
from data_transaction_detail a  
where date_format(TRADE_DATE,'%Y%m%d') >= date_format(DATE_SUB(now(),INTERVAL 12 month),'%Y%m%d')
and a.APPLY_ID=APPLYID 
and a.AREA_CODE=AREACODE
group by ORG_CODE,ACCOUNT
)  t 
where  TIMESTAMPDIFF(month,START_DATE,END_DATE)>=3
)t2 
where t1.ORG_CODE=t2.ORG_CODE and ifnull(t1.ACCOUNT,0)=ifnull(t2.ACCOUNT,0)
and t1.TRADE_DATE >= t2.START_DATE and t1.TRADE_DATE<=t2.END_DATE
and t1.APPLY_ID=APPLYID
and t1.AREA_CODE=AREACODE;

commit;


 
set VV_TASK='将 收入总额、关系人收入总额、关系人支出总额 插入临时表';

insert  into DATA_BILL_APPLY_GRADE_STD_TEMP(
APPLY_ID,ID_CARD,TYPE,AREA_CODE,TRADE_MON,
CARD_INC_AMT,CARD_INC_RELA_AMT,CARD_EXP_RELA_AMT,
ALIPAYSH_INC_AMT,ALIPAYSH_INC_RELA_AMT,ALIPAYSH_EXP_RELA_AMT,
ALIPAY_INC_AMT,ALIPAY_INC_RELA_AMT,ALIPAY_EXP_RELA_AMT,
WECHATSH_INC_AMT,WECHATSH_INC_RELA_AMT,WECHATSH_EXP_RELA_AMT,
WECHAT_INC_AMT,WECHAT_INC_RELA_AMT,WECHAT_EXP_RELA_AMT
)
select
APPLYID as APPLY_ID, IDCARD as ID_CARD, PTYPE as TYPE, AREACODE as AREA_CODE, substr(TRADE_DATE,1,7) as TRADE_MON ,
sum(case when a.ORG_CODE not in ('alipay','alipaysh','wechat','wechatsh') then a.INCOME_AMOUNT else 0 end) as CARD_INC_AMT, 
sum(case when a.ORG_CODE not in ('alipay','alipaysh','wechat','wechatsh') and  b.CUST_NAME is not null then a.INCOME_AMOUNT  else 0 end ) as CARD_INC_RELA_AMT,
sum(case when a.ORG_CODE not in ('alipay','alipaysh','wechat','wechatsh') and  b.CUST_NAME is not null then a.EXPEND_AMOUNT  else 0 end ) as CARD_EXP_RELA_AMT,

sum(case when a.ORG_CODE = 'alipaysh'  then a.INCOME_AMOUNT else 0 end) as ALIPAYSH_INC_AMT, 
sum(case when a.ORG_CODE = 'alipaysh'  and  b.CUST_NAME is not null then a.INCOME_AMOUNT  else 0 end ) as ALIPAYSH_INC_RELA_AMT,
sum(case when a.ORG_CODE = 'alipaysh'  and  b.CUST_NAME is not null then a.EXPEND_AMOUNT  else 0 end ) as ALIPAYSH_EXP_RELA_AMT,

sum(case when a.ORG_CODE = 'alipay'  then a.INCOME_AMOUNT else 0  end) as ALIPAY_INC_AMT, 
sum(case when a.ORG_CODE = 'alipay'  and  b.CUST_NAME is not null then a.INCOME_AMOUNT  else 0 end ) as ALIPAY_INC_RELA_AMT,
sum(case when a.ORG_CODE = 'alipay'  and  b.CUST_NAME is not null then a.EXPEND_AMOUNT  else 0 end ) as ALIPAY_EXP_RELA_AMT,

sum(case when a.ORG_CODE = 'wechatsh'  then a.INCOME_AMOUNT else 0  end) as WECHATSH_INC_AMT, 
sum(case when a.ORG_CODE = 'wechatsh'  and  b.CUST_NAME is not null then a.INCOME_AMOUNT  else 0 end ) as WECHATSH_INC_RELA_AMT,
sum(case when a.ORG_CODE = 'wechatsh'  and  b.CUST_NAME is not null then a.EXPEND_AMOUNT  else 0 end ) as WECHATSH_EXP_RELA_AMT,

sum(case when a.ORG_CODE = 'wechat'  then a.INCOME_AMOUNT else 0  end) as WECHAT_INC_AMT, 
sum(case when a.ORG_CODE = 'wechat'  and  b.CUST_NAME is not null then a.INCOME_AMOUNT  else 0 end ) as WECHAT_INC_RELA_AMT,
sum(case when a.ORG_CODE = 'wechat'  and  b.CUST_NAME is not null then a.EXPEND_AMOUNT  else 0 end ) as WECHAT_EXP_RELA_AMT

from data_transaction_detail_std a
LEFT JOIN data_bill_apply_rela b on a.OTHER_NAME =b.CUST_NAME and b.APPLY_ID=APPLYID and b.ID_CARD=IDCARD and b.TYPE=PTYPE and b.AREA_CODE=AREACODE
where  date_format(TRADE_DATE,'%Y%m%d') >= date_format(DATE_SUB(now(),INTERVAL 12 month),'%Y%m%d')
and a.APPLY_ID=APPLYID
and a.AREA_CODE=AREACODE
group by substr(TRADE_DATE,1,7);

commit ;


set VV_TASK='将 银行卡异常收入总额 插入临时表';
insert  into DATA_BILL_APPLY_GRADE_STD_TEMP(APPLY_ID,ID_CARD,TYPE,AREA_CODE,TRADE_MON,CARD_INC_ABNORMAL_AMT)
 select APPLYID as APPLY_ID, IDCARD as ID_CARD, PTYPE as TYPE, AREACODE as AREA_CODE, TRADE_MON, sum(CARD_INC_ABNORMAL_AMT) as CARD_INC_ABNORMAL_AMT from (
   select 
   TRADE_MON ,
   sum(INCOME_AMOUNT) as  CARD_INC_ABNORMAL_AMT
   from (
   select 
   INCOME_AMOUNT ,
	 substr(TRADE_DATE,1,7) as TRADE_MON,
   concat_ws('',REMARK,POSTSCRIPT,TRADE_TYPE) as REMARK
   from data_transaction_detail_std   a 
   LEFT JOIN data_bill_apply_rela b on a.OTHER_NAME =b.CUST_NAME and b.APPLY_ID=APPLYID and b.ID_CARD=IDCARD and b.TYPE=PTYPE and b.AREA_CODE=AREACODE
   where  ORG_CODE not in ('alipay','alipaysh','wechat','wechatsh')
   and date_format(TRADE_DATE,'%Y%m%d') >= date_format(DATE_SUB(now(),INTERVAL 12 month),'%Y%m%d')
   and a.APPLY_ID=APPLYID
	 and a.AREA_CODE=AREACODE
   and b.CUST_NAME is null
   
   ) t
   where REMARK like '%银行%' or REMARK like '%小额贷款%' or REMARK like '%小贷%' or REMARK like '%担保%' 
   or REMARK like '%融资租赁%' or REMARK like '%P2P%'  or REMARK like '%贷款发放%'  
   group by TRADE_MON
/**
union all 
   select 
   substr(TRADE_DATE,1,7) as TRNDE_MON ,
   sum(t1.INCOME_AMOUNT) as  CARD_INC_ABNORMAL_AMT 
   from (
   select  distinct a.ID,a.OTHER_NAME,a.INCOME_AMOUNT ,a.TRADE_DATE
   from (
   select  ID,APPLY_ID,OTHER_NAME, TRADE_DATE, INCOME_AMOUNT 
   from data_transaction_detail_std 
   where ORG_CODE not in ('alipay','alipaysh','wechat','wechatsh') 
   and date_format(TRADE_DATE,'%Y%m%d') >= date_format(DATE_SUB(now(),INTERVAL 12 month),'%Y%m%d')
   and TRADE_DATE is not null 
   and INCOME_AMOUNT>=500000 
   and APPLY_ID=APPLYID
	 and AREA_CODE=AREACODE
   ) a ,
   (select  ID,APPLY_ID,OTHER_NAME, TRADE_DATE, EXPEND_AMOUNT 
   from data_transaction_detail_std 
   where  ORG_CODE not in ('alipay','alipaysh','wechat','wechatsh')
   and date_format(TRADE_DATE,'%Y%m%d') >= date_format(DATE_SUB(now(),INTERVAL 12 month),'%Y%m%d')
   and TRADE_DATE is not null 
   and EXPEND_AMOUNT>=500000 
   and APPLY_ID=APPLYID
	 and AREA_CODE=AREACODE
   ) b
   where a.INCOME_AMOUNT=b.EXPEND_AMOUNT
   and a.OTHER_NAME=b.OTHER_NAME
   and  TIMESTAMPDIFF(day,a.TRADE_DATE,b.TRADE_DATE)>=0
   and  TIMESTAMPDIFF(day,a.TRADE_DATE,b.TRADE_DATE)<=2
   ) t1 
   LEFT JOIN data_bill_apply_rela t2 on t1.OTHER_NAME =t2.CUST_NAME and t2.APPLY_ID=APPLYID and t2.ID_CARD=IDCARD and t2.TYPE=PTYPE and t2.AREA_CODE=AREACODE
   where t2.CUST_NAME is null 
   group by substr(TRADE_DATE,1,7)  
	 */
)tt
group by TRADE_MON ;

commit;


set VV_TASK='将 银行卡提现收入总额 插入临时表';
insert  into DATA_BILL_APPLY_GRADE_STD_TEMP(APPLY_ID,ID_CARD,TYPE,AREA_CODE,TRADE_MON,CARD_INC_WITHDRAW_AMT)
select APPLYID as APPLY_ID, IDCARD as ID_CARD, PTYPE as TYPE, AREACODE as AREA_CODE,
substr(TRADE_DATE,1,7) as TRADE_MON ,
sum(INCOME_AMOUNT) as  CARD_INC_WITHDRAW_AMT
from data_transaction_detail_std a
LEFT JOIN data_bill_apply_rela b on a.OTHER_NAME =b.CUST_NAME and b.APPLY_ID=APPLYID and b.ID_CARD=IDCARD and b.TYPE=PTYPE and b.AREA_CODE=AREACODE
where  ORG_CODE not in ('alipay','alipaysh','wechat','wechatsh')
and date_format(TRADE_DATE,'%Y%m%d') >= date_format(DATE_SUB(now(),INTERVAL 12 month),'%Y%m%d')
and concat_ws('',REMARK,POSTSCRIPT,TRADE_TYPE) like '%提现%' 
and a.APPLY_ID=APPLYID
and a.AREA_CODE=AREACODE
and b.CUST_NAME is null
group by substr(TRADE_DATE,1,7) ;

commit;


set VV_TASK='将 支付宝商户收费支出总金额 插入临时表';
insert  into DATA_BILL_APPLY_GRADE_STD_TEMP(APPLY_ID,ID_CARD,TYPE,AREA_CODE,TRADE_MON,ALIPAYSH_EXP_AMT)
select APPLYID as APPLY_ID, IDCARD as ID_CARD, PTYPE as TYPE, AREACODE as AREA_CODE,
substr(TRADE_DATE,1,7) as TRADE_MON ,
sum(EXPEND_AMOUNT) as  ALIPAYSH_EXP_AMT
from data_transaction_detail_std a
LEFT JOIN data_bill_apply_rela b on a.OTHER_NAME =b.CUST_NAME and b.APPLY_ID=APPLYID and b.ID_CARD=IDCARD and b.TYPE=PTYPE and b.AREA_CODE=AREACODE
where  ORG_CODE = 'alipaysh'
and date_format(TRADE_DATE,'%Y%m%d') >= date_format(DATE_SUB(now(),INTERVAL 12 month),'%Y%m%d')
and concat_ws('',REMARK,POSTSCRIPT,TRADE_TYPE) like '%收费%'
and a.APPLY_ID=APPLYID
and a.AREA_CODE=AREACODE
and b.CUST_NAME is null
group by substr(TRADE_DATE,1,7);

commit;


set VV_TASK='将 支付宝个人退款金额 插入临时表';
insert  into DATA_BILL_APPLY_GRADE_STD_TEMP(APPLY_ID,ID_CARD,TYPE,AREA_CODE,TRADE_MON,ALIPAY_REFUND_AMT)
select APPLYID as APPLY_ID, IDCARD as ID_CARD, PTYPE as TYPE, AREACODE as AREA_CODE,
substr(TRADE_DATE,1,7) as TRADE_MON ,
sum(INCOME_AMOUNT) as  ALIPAY_REFUND_AMT
from data_transaction_detail_std a
LEFT JOIN data_bill_apply_rela b on a.OTHER_NAME =b.CUST_NAME  and b.APPLY_ID=APPLYID and b.ID_CARD=IDCARD and b.TYPE=PTYPE and b.AREA_CODE=AREACODE
where  ORG_CODE = 'alipay'
and date_format(TRADE_DATE,'%Y%m%d') >= date_format(DATE_SUB(now(),INTERVAL 12 month),'%Y%m%d')
and concat_ws('',REMARK,POSTSCRIPT,TRADE_TYPE) like '%退款成功%'
and a.APPLY_ID=APPLYID
and a.AREA_CODE=AREACODE
and b.CUST_NAME is null
group by substr(TRADE_DATE,1,7);

commit;



set VV_TASK='将 微信商户扣除交易费用、退款金额 插入临时表';
insert  into DATA_BILL_APPLY_GRADE_STD_TEMP(APPLY_ID,ID_CARD,TYPE,AREA_CODE,TRADE_MON,WECHATSH_SERVICE_AMT,WECHATSH_REFUND_AMT)
select APPLYID as APPLY_ID, IDCARD as ID_CARD, PTYPE as TYPE, AREACODE as AREA_CODE,
substr(TRADE_DATE,1,7) as TRADE_MON ,
sum(case when concat_ws('',REMARK,POSTSCRIPT,TRADE_TYPE) like '%扣除交易费用%' then EXPEND_AMOUNT else 0 end ) as  WECHATSH_SERVICE_AMT,
sum(case when concat_ws('',REMARK,POSTSCRIPT,TRADE_TYPE) like '%退款%' then EXPEND_AMOUNT else 0 end ) as  WECHATSH_REFUND_AMT
from data_transaction_detail_std a
LEFT JOIN data_bill_apply_rela b on a.OTHER_NAME =b.CUST_NAME  and b.APPLY_ID=APPLYID and b.ID_CARD=IDCARD and b.TYPE=PTYPE and b.AREA_CODE=AREACODE
where  ORG_CODE = 'wechatsh'
and date_format(TRADE_DATE,'%Y%m%d') >= date_format(DATE_SUB(now(),INTERVAL 12 month),'%Y%m%d')
and a.APPLY_ID=APPLYID
and a.AREA_CODE=AREACODE
and b.CUST_NAME is null
group by substr(TRADE_DATE,1,7);

commit;



set VV_TASK='将 月度经营性交易笔数 插入临时表';
insert  into DATA_BILL_APPLY_GRADE_STD_TEMP(APPLY_ID,ID_CARD,TYPE,AREA_CODE,TRADE_MON,VALID_BILL_CNT)
select APPLYID as APPLY_ID, IDCARD as ID_CARD, PTYPE as TYPE, AREACODE as AREA_CODE,
substr(TRADE_DATE,1,7) as TRADE_MON ,   
sum(VALID_FLAG)        as VALID_BILL_CNT 
from (

select TRADE_DATE, VALID_FLAG from (
select 
TRADE_DATE,
case when b.CUST_NAME is null then 1 else 0 end  as VALID_FLAG
from data_transaction_detail_std a 
left join data_bill_apply_rela b on a.OTHER_NAME=b.CUST_NAME and b.APPLY_ID=APPLYID and b.ID_CARD=IDCARD and b.TYPE=PTYPE and b.AREA_CODE=AREACODE
where a.ORG_CODE not in ('alipay','alipaysh','wechat','wechatsh')
and date_format(TRADE_DATE,'%Y%m%d') >= date_format(DATE_SUB(now(),INTERVAL 12 month),'%Y%m%d')
and a.APPLY_ID=APPLYID
and a.AREA_CODE=AREACODE
union all
select 
TRADE_DATE,
case when b.CUST_NAME is null then 1 else 0 end  as VALID_FLAG
from data_transaction_detail_std a 
left join data_bill_apply_rela b on a.OTHER_NAME=b.CUST_NAME and b.CUST_TYPE=1 and b.APPLY_ID=APPLYID and b.ID_CARD=IDCARD and b.TYPE=PTYPE and b.AREA_CODE=AREACODE
where a.ORG_CODE ='alipaysh'
and date_format(TRADE_DATE,'%Y%m%d') >= date_format(DATE_SUB(now(),INTERVAL 12 month),'%Y%m%d')
and a.APPLY_ID=APPLYID
and a.AREA_CODE=AREACODE
union all
select 
TRADE_DATE,
case when b.CUST_NAME is null and concat_ws('',REMARK,POSTSCRIPT,TRADE_TYPE) not like '%退款成功%' then 1 else 0 end  as VALID_FLAG
from data_transaction_detail_std a 
left join data_bill_apply_rela b on a.OTHER_NAME=b.CUST_NAME and b.CUST_TYPE=1 and b.APPLY_ID=APPLYID and b.ID_CARD=IDCARD and b.TYPE=PTYPE and b.AREA_CODE=AREACODE
where a.ORG_CODE ='alipay'
and date_format(TRADE_DATE,'%Y%m%d') >= date_format(DATE_SUB(now(),INTERVAL 12 month),'%Y%m%d')
and a.APPLY_ID=APPLYID
and a.AREA_CODE=AREACODE
union all
select 
TRADE_DATE,
case when b.CUST_NAME is null and concat_ws('',REMARK,POSTSCRIPT,TRADE_TYPE) not like '%扣除交易费用%' and concat_ws('',REMARK,POSTSCRIPT,TRADE_TYPE) not like '%退款%' then 1 else 0 end  as VALID_FLAG
from data_transaction_detail_std a 
left join data_bill_apply_rela b on a.OTHER_NAME=b.CUST_NAME and b.CUST_TYPE=1 and b.APPLY_ID=APPLYID and b.ID_CARD=IDCARD and b.TYPE=PTYPE and b.AREA_CODE=AREACODE
where a.ORG_CODE ='wechatsh'
and date_format(TRADE_DATE,'%Y%m%d') >= date_format(DATE_SUB(now(),INTERVAL 12 month),'%Y%m%d')
and a.APPLY_ID=APPLYID
and a.AREA_CODE=AREACODE
)t
where VALID_FLAG=1

)t  
group by substr(TRADE_DATE,1,7);

commit;



set VV_TASK='将 临时表数据汇总';
insert into DATA_BILL_APPLY_GRADE_STD
select
APPLY_ID,
ID_CARD,
TYPE,
AREA_CODE,
CURRENT_TIMESTAMP as UPDATE_TIME,
TRADE_MON,
max(ifnull(CARD_INC_AMT,0)),
max(ifnull(CARD_INC_RELA_AMT,0)),
max(ifnull(CARD_EXP_RELA_AMT,0)),
max(ifnull(CARD_INC_ABNORMAL_AMT,0)),
max(ifnull(CARD_INC_WITHDRAW_AMT,0)),
max(ifnull(ALIPAYSH_INC_AMT,0)),
max(ifnull(ALIPAYSH_INC_RELA_AMT,0)),
max(ifnull(ALIPAYSH_EXP_RELA_AMT,0)),
max(ifnull(ALIPAYSH_EXP_AMT,0)),
max(ifnull(ALIPAY_INC_AMT,0)),
max(ifnull(ALIPAY_INC_RELA_AMT,0)),
max(ifnull(ALIPAY_EXP_RELA_AMT,0)),
max(ifnull(ALIPAY_REFUND_AMT,0)),
max(ifnull(WECHATSH_INC_AMT,0)),
max(ifnull(WECHATSH_INC_RELA_AMT,0)),
max(ifnull(WECHATSH_EXP_RELA_AMT,0)),
max(ifnull(WECHATSH_SERVICE_AMT,0)),
max(ifnull(WECHATSH_REFUND_AMT,0)),
max(ifnull(WECHAT_INC_AMT,0)),
max(ifnull(WECHAT_INC_RELA_AMT,0)),
max(ifnull(WECHAT_EXP_RELA_AMT,0)),
null as BUS_INC_AMT,
max(ifnull(VALID_BILL_CNT,0))
from DATA_BILL_APPLY_GRADE_STD_TEMP
where APPLY_ID=APPLYID and ID_CARD=IDCARD and TYPE=PTYPE and AREA_CODE=AREACODE
group by TRADE_MON;

commit;


set VV_TASK='计算月度经营性总收入';
update DATA_BILL_APPLY_GRADE_STD 
set BUS_INC_AMT = 
CARD_INC_AMT - CARD_INC_RELA_AMT - CARD_INC_ABNORMAL_AMT - CARD_INC_WITHDRAW_AMT  + (case when CARD_INC_RELA_AMT - CARD_EXP_RELA_AMT> 0 then CARD_INC_RELA_AMT - CARD_EXP_RELA_AMT else 0 end)
+
ALIPAYSH_INC_AMT - ALIPAYSH_INC_RELA_AMT - ALIPAYSH_EXP_AMT
+
ALIPAY_INC_AMT - ALIPAY_INC_RELA_AMT - ALIPAY_REFUND_AMT + (case when ALIPAY_INC_RELA_AMT- ALIPAY_EXP_RELA_AMT > 0 then ALIPAY_INC_RELA_AMT - ALIPAY_EXP_RELA_AMT else 0 end)
+
WECHATSH_INC_AMT - WECHATSH_SERVICE_AMT - WECHATSH_REFUND_AMT
+ ( WECHAT_INC_AMT * 0.5)
where APPLY_ID=APPLYID and ID_CARD=IDCARD and TYPE=PTYPE and AREA_CODE=AREACODE ;

commit;

/**
set VV_TASK='删除 标准化流水数据';
delete from data_transaction_detail_std where APPLY_ID=APPLYID  AND AREA_CODE =AREACODE;
commit;	
set VV_TASK='删除临时表数据';
delete from data_bill_apply_grade_std_temp where APPLY_ID=APPLYID AND ID_CARD=IDCARD AND TYPE=PTYPE AND AREA_CODE =AREACODE;
commit;

*/


END;

