create definer = root@`%` view base_category_view as
select `c3`.`id`   AS `id`,
       `c1`.`id`   AS `category1_id`,
       `c1`.`name` AS `category1_name`,
       `c2`.`id`   AS `category2_id`,
       `c2`.`name` AS `category2_name`,
       `c3`.`id`   AS `category3_id`,
       `c3`.`name` AS `category3_name`
from ((`gmall`.`base_category1` `c1` join `gmall`.`base_category2` `c2` on ((`c2`.`category1_id` = `c1`.`id`)))
         join `gmall`.`base_category3` `c3` on ((`c3`.`category2_id` = `c2`.`id`)));

